class RemovePublishedDateToPosts < ActiveRecord::Migration[7.0]
  def change
  end
end
