
module.exports = {
        test: /plugin\.css$/,
        loaders: ['style-loader', 'css'],
    }